/**
 * SupabaseService
 * Handles eNumber → DID lookups and credential record storage.
 * This is your identity registry — row-level security must be enabled.
 */

import { createClient } from '@supabase/supabase-js';

const supabase = createClient(
  process.env.SUPABASE_URL,
  process.env.SUPABASE_SERVICE_KEY // service role — never expose to client
);

/**
 * Look up a DID by eNumber.
 * Returns null if eNumber not found.
 */
export async function getDIDByENumber(eNumber) {
  const { data, error } = await supabase
    .from('enumber_did_mapping')
    .select('did, created_at, status')
    .eq('enumber', eNumber)
    .eq('status', 'active')
    .single();

  if (error || !data) return null;
  return data.did;
}

/**
 * Store a KYC verification result linked to an eNumber and DID.
 * Called after successful verification, before credential issuance.
 */
export async function storeVerificationRecord({
  eNumber,
  did,
  verificationId,
  country,
  idType,
  verifiedAt,
  amlClear,
  credentialId = null
}) {
  const { data, error } = await supabase
    .from('kyc_verifications')
    .insert({
      enumber: eNumber,
      did,
      verification_id: verificationId,
      country,
      id_type: idType,
      verified_at: verifiedAt,
      aml_clear: amlClear,
      credential_id: credentialId,
      status: 'verified'
    })
    .select()
    .single();

  if (error) throw new Error(`Failed to store verification: ${error.message}`);
  return data;
}

/**
 * Update a verification record with the issued credential ID.
 * Called after Polygon ID issues the credential.
 */
export async function updateCredentialId(verificationId, credentialId) {
  const { error } = await supabase
    .from('kyc_verifications')
    .update({ credential_id: credentialId })
    .eq('verification_id', verificationId);

  if (error) throw new Error(`Failed to update credential ID: ${error.message}`);
}

/**
 * Check if an eNumber already has a valid KYC credential.
 * Prevents duplicate verifications.
 */
export async function getExistingVerification(eNumber) {
  const { data } = await supabase
    .from('kyc_verifications')
    .select('verification_id, credential_id, verified_at')
    .eq('enumber', eNumber)
    .eq('status', 'verified')
    .order('verified_at', { ascending: false })
    .limit(1)
    .single();

  return data || null;
}
