/**
 * DojahService
 * Abstracts all calls to Dojah's KYC API.
 * Swap this file out if you ever move to Smile ID or another provider.
 */

import axios from 'axios';

const BASE_URL = process.env.DOJAH_BASE_URL || 'https://api.dojah.io';
const APP_ID = process.env.DOJAH_APP_ID;
const PRIVATE_KEY = process.env.DOJAH_PRIVATE_KEY;

const dojahClient = axios.create({
  baseURL: BASE_URL,
  headers: {
    'AppId': APP_ID,
    'Authorization': PRIVATE_KEY,
    'Content-Type': 'application/json'
  },
  timeout: 30000 // 30s — allow for slower connections in Africa
});

/**
 * Verify a government-issued ID document.
 * @param {string} country - 'NG' | 'ZA' | 'KE' etc.
 * @param {string} idType  - 'BVN' | 'NIN' | 'PASSPORT' | 'DRIVERS_LICENSE' | 'NATIONAL_ID'
 * @param {string} idNumber
 * @returns {object} Dojah verification result
 */
export async function verifyGovernmentId({ country, idType, idNumber }) {
  const endpoint = resolveIdEndpoint(country, idType);

  const response = await dojahClient.get(endpoint, {
    params: { [idType.toLowerCase()]: idNumber }
  });

  return {
    verified: response.data?.entity !== null,
    data: response.data?.entity || null,
    provider: 'dojah',
    type: 'government_id'
  };
}

/**
 * Liveness check + facial match against a reference image.
 * @param {string} selfieBase64 - base64 encoded selfie image
 * @param {string} idImageBase64 - base64 encoded ID document photo (optional)
 */
export async function verifyBiometric({ selfieBase64, idImageBase64 }) {
  const payload = {
    selfie: selfieBase64,
    ...(idImageBase64 && { id: idImageBase64 })
  };

  const response = await dojahClient.post('/api/v1/kyc/selfie', payload);

  return {
    verified: response.data?.entity?.selfie_verified === true,
    confidence: response.data?.entity?.confidence_value || 0,
    livenessScore: response.data?.entity?.liveness_score || 0,
    provider: 'dojah',
    type: 'biometric'
  };
}

/**
 * AML watchlist screening — OFAC, UN, EU sanctions + PEP databases.
 * @param {string} firstName
 * @param {string} lastName
 * @param {string} dateOfBirth - 'YYYY-MM-DD'
 */
export async function screenAML({ firstName, lastName, dateOfBirth }) {
  const response = await dojahClient.post('/api/v1/aml/screening', {
    first_name: firstName,
    last_name: lastName,
    date_of_birth: dateOfBirth
  });

  const entity = response.data?.entity;

  return {
    clear: entity?.match_status === 'no_match',
    matchStatus: entity?.match_status || 'unknown',
    matches: entity?.matches || [],
    provider: 'dojah',
    type: 'aml'
  };
}

// ─── Internal helpers ──────────────────────────────────────────────────────────

function resolveIdEndpoint(country, idType) {
  // Map country + idType to the correct Dojah endpoint
  const map = {
    'NG:BVN':              '/api/v1/kyc/bvn',
    'NG:NIN':              '/api/v1/kyc/nin',
    'NG:PASSPORT':         '/api/v1/kyc/passport',
    'NG:DRIVERS_LICENSE':  '/api/v1/kyc/dl',
    'ZA:NATIONAL_ID':      '/api/v1/kyc/za/id',
    'ZA:PASSPORT':         '/api/v1/kyc/passport',
    'KE:NATIONAL_ID':      '/api/v1/kyc/ke/id',
    'KE:PASSPORT':         '/api/v1/kyc/passport',
    'GH:DRIVERS_LICENSE':  '/api/v1/kyc/gh/dl',
  };

  const key = `${country}:${idType}`;
  const endpoint = map[key];

  if (!endpoint) {
    throw new Error(`Unsupported country/ID type combination: ${country}/${idType}. Check Dojah docs for supported endpoints.`);
  }

  return endpoint;
}
