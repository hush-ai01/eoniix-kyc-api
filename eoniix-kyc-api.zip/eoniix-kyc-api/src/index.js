import 'dotenv/config';
import express from 'express';
import helmet from 'helmet';
import cors from 'cors';
import rateLimit from 'express-rate-limit';

import verifyRouter from './routes/verify.js';
import credentialRouter from './routes/credential.js';
import healthRouter from './routes/health.js';
import { errorHandler } from './middleware/errorHandler.js';
import { requestLogger } from './middleware/requestLogger.js';

const app = express();
const PORT = process.env.PORT || 3000;

// Security
app.use(helmet());
app.use(cors());
app.use(express.json({ limit: '10mb' })); // 10mb to allow base64 ID images
app.use(requestLogger);

// Rate limiting
app.use(rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.RATE_LIMIT_MAX) || 100,
  message: { error: 'Too many requests. Please try again later.' }
}));

// Routes
app.use('/health', healthRouter);
app.use('/v1/verify', verifyRouter);
app.use('/v1/credential', credentialRouter);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Route not found.' });
});

// Global error handler
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`\n🟢 Eoniix KYC API running on port ${PORT}`);
  console.log(`   Environment: ${process.env.NODE_ENV}`);
  console.log(`   Dojah mode:  ${process.env.DOJAH_ENV}\n`);
});

export default app;
